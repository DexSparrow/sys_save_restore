i=input
print(*zip(sorted(map(int,i().split())),sorted(map(int,i().split()))),sep=", ")
